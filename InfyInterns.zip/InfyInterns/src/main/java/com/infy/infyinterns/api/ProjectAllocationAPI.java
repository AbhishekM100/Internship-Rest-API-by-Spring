package com.infy.infyinterns.api;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.infyinterns.dto.MentorDTO;
import com.infy.infyinterns.dto.ProjectDTO;
import com.infy.infyinterns.exception.InfyInternException;
import com.infy.infyinterns.service.ProjectAllocationService;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
@RestController
@Validated
@RequestMapping(value="/infyinterns")
public class ProjectAllocationAPI
{
	@Autowired
	private ProjectAllocationService projectService;
	
	@Autowired
	private Environment environment;

    // add new project along with mentor details
	@PostMapping(value="/d/project")
    public ResponseEntity<String> allocateProject(@RequestBody @Valid ProjectDTO project) throws InfyInternException
    {
		Integer id = projectService.allocateProject(project);
		return new ResponseEntity<>(environment.getProperty("API.ALLOCATION_SUCCESS")+id, HttpStatus.CREATED);
    }

    // get mentors based on idea owner
	@GetMapping(value = "/mentor/{numberOfProjectsMentored}")
    public ResponseEntity<List<MentorDTO>> getMentors(@PathVariable Integer numberOfProjectsMentored) throws InfyInternException
    {
		return new ResponseEntity<>(projectService.getMentors(numberOfProjectsMentored), HttpStatus.OK);
    }
	
	@GetMapping(value = "/d/project/{projectId}")
	public EntityModel<ProjectDTO> getProject(@PathVariable  @Min(value = 1, message="{project.projectId.invalid}")
	@Max(value = 99, message = "{project.projectId.invalid}") Integer projectId) throws InfyInternException{
		ProjectDTO project = projectService.getProject(projectId);
		Link mentorLink = linkTo(methodOn(ProjectAllocationAPI.class).getMentor(project.getMentorDTO().getMentorId())).withRel("Mentor");
		return EntityModel.of(project,mentorLink);
	}
	
	@GetMapping(value = "/d/mentor/{mentorId}")
	public EntityModel<MentorDTO> getMentor(@PathVariable  @Min(value = 1000, message="{mentor.mentorid.invalid}")
	@Max(value = 9999, message = "{mentor.mentorid.invalid}") Integer mentorId) throws InfyInternException{
		MentorDTO project = projectService.getMentor(mentorId);
		return EntityModel.of(project);
	}

    // update the mentor of a project
	@PutMapping(value = "/d/project/{projectId}/{mentorId}")
    public ResponseEntity<String> updateProjectMentor(@PathVariable Integer projectId, @PathVariable @Min(value = 1000, message="{mentor.mentorid.invalid}")
	@Max(value = 9999, message = "{mentor.mentorid.invalid}") Integer mentorId) throws InfyInternException
    {
    	projectService.updateProjectMentor(projectId, mentorId);
    	return new ResponseEntity<>(environment.getProperty("API.PROJECT_UPDATE_SUCCESS"), HttpStatus.OK);
    }

    // delete a project
	@DeleteMapping(value = "/d/project/delete/{projectId}")
    public ResponseEntity<String> deleteProject(@PathVariable Integer projectId) throws InfyInternException
    {
		projectService.deleteProject(projectId);
		return new ResponseEntity<>(environment.getProperty("API.PROJECT_DELETE _SUCCESS"), HttpStatus.OK);
    }

}
