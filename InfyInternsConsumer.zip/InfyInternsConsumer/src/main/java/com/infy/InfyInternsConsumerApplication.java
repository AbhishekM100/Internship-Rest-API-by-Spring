package com.infy;

import java.time.LocalDate;
import java.time.Month;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.infy.dto.MentorDTO;
import com.infy.dto.ProjectDTO;

@SpringBootApplication
public class InfyInternsConsumerApplication implements CommandLineRunner{
	
	public static final Log LOGGER = LogFactory.getLog(InfyInternsConsumerApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(InfyInternsConsumerApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
//		ProjectDTO projectDTO = new ProjectDTO();
//		projectDTO.setProjectId(14);
//		projectDTO.setIdeaOwner(10015);
//		projectDTO.setProjectName("Insurance App");
//		projectDTO.setReleaseDate(LocalDate.now());
//		MentorDTO mentor = new MentorDTO();
//		mentor.setMentorId(1004);
//		mentor.setMentorName("Allen");
//		mentor.setNumberOfProjectsMentored(0);
//		projectDTO.setMentorDTO(mentor);
//		allocateProject(projectDTO);
		

//		updateProjectMentor(2, 1003);
//		deleteProject(6);
		getMentors(1);
	}

	private void deleteProject(int projectId) {
		// TODO Auto-generated method stub
		String url = "http://localhost:8765/infyinterns/project/{projectId}";
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.delete(url, projectId);
		LOGGER.info("Project deleted successfully.");
		LOGGER.info("\n");
	}

	public void allocateProject(ProjectDTO project) {
		// TODO Auto-generated method stub
		String url = "http://localhost:8765/infyinterns/project";
		RestTemplate restTemplate = new RestTemplate();
		String response = restTemplate.postForObject(url, project, String.class);
		LOGGER.info(response);
		LOGGER.info("\n");
	}
	
	public void updateProjectMentor(Integer projectId, Integer mentorId) {
		String url = "http://localhost:8765/infyinterns/project/{projectId}/{mentorId}";
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.put(url, null, projectId, mentorId);
		LOGGER.info("Project mentor updated successfully.");
		LOGGER.info("\n");
	}

	
	public void getMentors(Integer noOfProjectAllocated) {
		Integer i;
		String url = "http://localhost:8765/infyinterns/mentor/{noOfProjectAllocated}";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<MentorDTO[]> response =
				  restTemplate.getForEntity(
						  url,
				  MentorDTO[].class,
				  noOfProjectAllocated);
		MentorDTO[] mentors = response.getBody();
	   
		for(i=0; i<mentors.length; i++) {
			System.out.println(mentors[i].getMentorName());
		}
	}
	
}

