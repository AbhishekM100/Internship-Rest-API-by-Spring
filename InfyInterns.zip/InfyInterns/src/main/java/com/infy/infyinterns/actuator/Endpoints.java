package com.infy.infyinterns.actuator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.stereotype.Component;

import com.infy.infyinterns.dto.MentorDTO;
import com.infy.infyinterns.entity.Mentor;
import com.infy.infyinterns.repository.MentorRepository;

@Component
@Endpoint(id = "mentors")

public class Endpoints {
	
	@Autowired
	private MentorRepository mentorRepository;

	@ReadOperation
	public List<MentorDTO> getAllMentors() {
		List<Mentor> mentors = (List<Mentor>) mentorRepository.findAll();
		List<MentorDTO> mentorList = new ArrayList<>();
		for(Mentor mentor1: mentors) {
			MentorDTO mentorDTO = new MentorDTO();
			mentorDTO.setMentorId(mentor1.getMentorId());
			mentorDTO.setMentorName(mentor1.getMentorName());
			mentorDTO.setNumberOfProjectsMentored(mentor1.getNumberOfProjectsMentored());
			mentorList.add(mentorDTO);
		}
		return mentorList;
	}
	
}
