package com.infy.infyinterns;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfyInternsApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfyInternsApplication.class, args);
	}

}
