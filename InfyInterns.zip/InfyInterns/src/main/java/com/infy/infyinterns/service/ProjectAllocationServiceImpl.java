package com.infy.infyinterns.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.infyinterns.dto.MentorDTO;
import com.infy.infyinterns.dto.ProjectDTO;
import com.infy.infyinterns.entity.Mentor;
import com.infy.infyinterns.entity.Project;
import com.infy.infyinterns.exception.InfyInternException;
import com.infy.infyinterns.repository.MentorRepository;
import com.infy.infyinterns.repository.ProjectRepository;
@Service(value = "projectService")
@Transactional
public class ProjectAllocationServiceImpl implements ProjectAllocationService {
	
	@Autowired
	 private ProjectRepository projectRepository;
	
	@Autowired
	private MentorRepository mentorRepository;

	@Override
	public Integer allocateProject(ProjectDTO project) throws InfyInternException {
		Optional<Mentor> opt = mentorRepository.findById(project.getMentorDTO().getMentorId());
		Mentor mentor = opt.orElseThrow(()-> new InfyInternException("Service.MENTOR_NOT_FOUND"));
		if(mentor.getNumberOfProjectsMentored()>=3) {
			throw new InfyInternException("Service.CANNOT_ALLOCATE_PROJECT");
		}
		Project project2 = new Project();
		project2.setIdeaOwner(project.getIdeaOwner());
		project2.setMentor(mentor);
		project2.setProjectId(project.getProjectId());
		project2.setProjectName(project.getProjectName());
		project2.setReleaseDate(project.getReleaseDate());
		int noOfProjects = mentor.getNumberOfProjectsMentored();
		mentor.setNumberOfProjectsMentored(++noOfProjects);
		return projectRepository.save(project2).getProjectId();
	}
	
	@Override
	public ProjectDTO getProject(Integer projectId) throws InfyInternException {
		// TODO Auto-generated method stub
		Optional<Project> opt = projectRepository.findById(projectId);
		Project project = opt.orElseThrow(()-> new InfyInternException("Service.PROJECT_NOT_FOUND"));
		ProjectDTO project2 = new ProjectDTO();
		project2.setProjectId(projectId);
		project2.setIdeaOwner(project.getIdeaOwner());
		MentorDTO mentor = new MentorDTO();
		mentor.setMentorId(project.getMentor().getMentorId());
		mentor.setMentorName(project.getMentor().getMentorName());
		mentor.setNumberOfProjectsMentored(project.getMentor().getNumberOfProjectsMentored());
		project2.setMentorDTO(mentor);
		project2.setProjectId(project.getProjectId());
		project2.setProjectName(project.getProjectName());
		project2.setReleaseDate(project.getReleaseDate());
		return project2;
	}
	
	@Override
	public MentorDTO getMentor(Integer mentorId) throws InfyInternException {
		// TODO Auto-generated method stub
		Optional<Mentor> opt = mentorRepository.findById(mentorId);
		Mentor mentor = opt.orElseThrow(()-> new InfyInternException("Service.MENTOR_NOT_FOUND"));
		MentorDTO mentor2 = new MentorDTO();
		mentor2.setMentorId(mentorId);
		mentor2.setMentorName(mentor.getMentorName());
		mentor2.setNumberOfProjectsMentored(mentor.getNumberOfProjectsMentored());
		return mentor2;
	}


	
	@Override
	public List<MentorDTO> getMentors(Integer numberOfProjectsMentored) throws InfyInternException {
		List<Mentor> mentorList = mentorRepository.findByNumberOfProjectsMentored(numberOfProjectsMentored);
		if(mentorList.isEmpty()) {
			throw new InfyInternException("Service.MENTOR_NOT_FOUND");
		}
		List<MentorDTO> mentorDTOs = new ArrayList<>();
		for(Mentor member : mentorList) {
			MentorDTO mentor = new MentorDTO();
			mentor.setMentorId(member.getMentorId());
			mentor.setMentorName(member.getMentorName());
			mentor.setNumberOfProjectsMentored(member.getNumberOfProjectsMentored());
			mentorDTOs.add(mentor);
		}
		return mentorDTOs;
	}


	@Override
	public void updateProjectMentor(Integer projectId, Integer mentorId) throws InfyInternException {
		Optional<Mentor> opt = mentorRepository.findById(mentorId);
		Mentor mentor = opt.orElseThrow(()-> new InfyInternException("Service.MENTOR_NOT_FOUND"));
		if(mentor.getNumberOfProjectsMentored()>=3) {
			throw new InfyInternException("Service.CANNOT_ALLOCATE_PROJECT");
		}
		Optional<Project> proj = projectRepository.findById(projectId);
		Project project = proj.orElseThrow(()-> new InfyInternException("Service.PROJECT_NOT_FOUND"));
		project.getMentor().setNumberOfProjectsMentored(project.getMentor().getNumberOfProjectsMentored() - 1);
		project.setMentor(mentor);
		Integer noOfProjects = mentor.getNumberOfProjectsMentored()+1;
		mentor.setNumberOfProjectsMentored(noOfProjects);
		}

	@Override
	public void deleteProject(Integer projectId) throws InfyInternException {
		Optional<Project> proj = projectRepository.findById(projectId);
		Project project = proj.orElseThrow(()-> new InfyInternException("Service.PROJECT_NOT_FOUND"));
		if(project.getMentor()==null) {
			projectRepository.deleteById(projectId);
		}
	    Mentor mentor = project.getMentor();
	    mentor.setNumberOfProjectsMentored(mentor.getNumberOfProjectsMentored()-1);	
	    project.setMentor(null);
	    projectRepository.delete(project);
	    }

	
}