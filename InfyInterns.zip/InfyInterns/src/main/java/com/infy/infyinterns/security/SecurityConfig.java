package com.infy.infyinterns.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;


@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	
	//Authentication
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception{
		auth.inMemoryAuthentication().withUser("Jhon").password(passwordEncoder().encode("jhonjones100")).roles("DEAN")
		.and().withUser("Abhi").password(passwordEncoder().encode("Abhishek100")).roles("MENTOR");
		
	}
	
	//Authorization
	@Override
	public void configure(HttpSecurity http) throws Exception{
		http.authorizeRequests().antMatchers("/infyinterns/d/**").hasRole("DEAN").anyRequest().authenticated().and().httpBasic();
		//http.authorizeRequests().antMatchers("/infyinterns/project/**").hasRole("MENTOR").anyRequest().authenticated().and().httpBasic();
		http.csrf().disable();
	}
	
	@Bean
	BCryptPasswordEncoder passwordEncoder() {
		// TODO Auto-generated method stub
		return new BCryptPasswordEncoder();
	}

}
